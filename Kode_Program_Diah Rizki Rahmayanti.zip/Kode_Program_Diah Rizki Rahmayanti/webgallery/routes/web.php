<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\RegisterController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\AlbumController;
use App\Http\Controllers\FotoController;
use App\Http\Controllers\LikeController;
use App\Http\Controllers\KomentarController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('beranda');
});

Route::get('/register', function () {
    return view('register');
});

Route::get('/login', function () {
    return view('login');
});

Route::get('/home', function () {
    return view('home');
});

Route::get('/gallery', function () {
    return view('gallery');
});

Route::get('/album', function () {
    return view('album');
});

Route::get('/tambahfoto', function () {
    return view('tambahfoto');
});

Route::get('/foto', function () {
    return view('foto');
});

Route::get('/komentar', function () {
    return view('komentar');
});

Route::get('/lihatkomentar', function () {
    return view('lihatkomentar');
});

Route::get('/register', [RegisterController::class, 'tampildaftar']);
Route::post('/register', [RegisterController::class, 'aksidaftar']);

Route::get('/login', [LoginController::class, 'tampil']);
Route::post('/home', [LoginController::class, 'login']);
Route::get('/logout', [LoginController::class,'logout']);

Route::get('/gallery', [AlbumController::class, 'album']);
Route::post('/gallery', [AlbumController::class, 'tambahAlbum']);

Route::get('/tambahfoto/{AlbumID}', [FotoController::class, 'foto']);
Route::get('/foto/{AlbumID}', [FotoController::class, 'foto2']);
Route::get('/home', [FotoController::class, 'home']);
Route::post('/album/{AlbumID}', [FotoController::class, 'tambahFoto']); 
Route::get('/beranda', [FotoController::class, 'home1']);
Route::get('/hapusfoto/{FotoID}', [FotoController::class,'hapusFoto']);

Route::get('/beranda2/{FotoID}', [LikeController::class, 'lihatFoto']);
Route::post('/berilike/{FotoID}', [LikeController::class, 'like']);

Route::get('/komentar/{FotoID}', [KomentarController::class, 'tampilkomentar']);
Route::post('/lihatkomentar/{FotoID}', [KomentarController::class, 'tambahKomentar']);
Route::get('/lihatkomentar/{FotoID}', [KomentarController::class, 'lihatKomentar']);

