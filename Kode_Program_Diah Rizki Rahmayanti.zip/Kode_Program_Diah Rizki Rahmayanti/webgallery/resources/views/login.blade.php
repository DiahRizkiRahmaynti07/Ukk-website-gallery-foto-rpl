<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login</title>
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      margin: 0;
      padding: 0;
      display: flex;
      align-items: center;
      justify-content: center;
      height: 100vh;
      background-image: url('asset/images/yaya.jpg');
    }

    header {
      background-color: #ff9999;
      color: #fff;
      padding: 10px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      width: 100%;
      position: fixed;
      top: 0;
    }

    h1 {
      margin: 0;
      font-size: 24px; 
    }

    nav {
      display: flex;
      gap: 20px; 
    }

    nav a {
      text-decoration: none;
      color: #fff;
      font-size: 18px;
    }

    .login-container {
      background-color: rgba(255, 255, 255, 0.8);
      padding: 30px;
      border-radius: 8px;
      box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
      max-width: 400px;
      width: 100%;
      text-align: center;
      margin-top: 80px; 
    }

    .login-container h2 {
      color: #333;
    }

    .form-group {
      margin-bottom: 20px;
    }

    .form-group label {
      display: block;
      margin-bottom: 8px;
      color: #555;
    }

    .form-group input {
      width: 100%;
      padding: 12px;
      border: 1px solid #ddd;
      border-radius: 4px;
      box-sizing: border-box;
    }

    .form-group button {
      background-color: #2ecc71;
      color: #fff;
      padding: 12px 20px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      font-size: 16px;
      transition: background-color 0.3s ease;
    }

    .form-group button:hover {
      background-color: #27ae60;
    }

    .forgot-password {
      color: #007bff;
      text-decoration: none;
      margin-top: 10px;
      display: inline-block;
      font-size: 14px; 
    }

    .logout-button {
      background: #ffb3b3;
      padding: 8px 16px;
      border-radius: 20px;
    }

    .logout-button:hover {
      background: #00ffff;
    }

    
  </style>
</head>
<body>
 
  <header>
    <h1>Web Galeri Foto</h1>
    <nav>
    <a href="/beranda" class="logout-button">Logout</a>
    
      </div>
    </nav>
  </header>

  <div class="login-container">
    <svg xmlns="http://www.w3.org/2000/svg" width="80" height="80" fill="currentColor" class="bi bi-person-circle" viewBox="0 0 16 16">
      <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0"/>
      <path fill-rule="evenodd" d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8m8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1"/>
    </svg>
    
    
    <br>
    <strong style="font-family:times new roman;color:red">{{ session()->get('pesan') ?? ''}}</strong>
   
     <form action="/home" method="POST">
    @csrf
    <h1>Login</h1>
    <div class="form-group">
      <label for="username">Username:</label>
      <input type="text" id="username" name="username" required>
    </div>

    <div class="form-group">
      <label for="password">Password:</label>
      <input type="password" id="password" name="password" required>
    </div>

    <div class="form-group">
      <button type="submit">Login</button>
    </div>

    <p>Belum punya akun? <a href="register"> Register</a></p>
  </div>


</body>
</html>