<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Tambah Album</title>
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      margin: 0;
      padding: 0;
      background-image: url('asset/images/yaya.jpg');
    }

    header {
      background-color: #ff9999;
      color: #fff;
      padding: 10px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    nav {
      text-align: right;
      padding: 10px;
    }

    nav a {
      color: #333;
      text-decoration: none;
      margin: 0 15px;
      font-size: 16px;
    }

    .content {
      background-color: #fff;
      border-radius: 8px;
      box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
      max-width: 600px;
      margin: 20px auto;
      padding: 20px;
    }

    .form-group {
      margin-bottom: 15px;
    }

    .form-group label {
      display: block;
      margin-bottom: 5px;
      color: #555;
    }

    .form-group input {
      width: 100%;
      padding: 8px;
      border: 1px solid #ddd;
      border-radius: 4px;
      box-sizing: border-box;
    }

    .form-group textarea {
      width: 100%;
      padding: 8px;
      border: 1px solid #ddd;
      border-radius: 4px;
      box-sizing: border-box;
      resize: vertical;
    }

    .form-group button {
      background-color: #2ecc71;
      color: #fff;
      padding: 10px 15px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      font-size: 14px;
      transition: background-color 0.3s ease;
    }

    .form-group button:hover {
      background-color: #27ae60;
    }

    footer {
      background-color: #ff9999;
      color: #fff;
      text-align: center;
      padding: 5px;
      position: fixed;
      bottom: 0;
      width: 100%;
    }
    
    .logout-button {
            background: #ffb3b3;
            padding: 8px 16px;
            border-radius: 20px;
        }

        .logout-button:hover {
            background: #00ffff;
        }
        
  </style>
</head>
<body>

  <header>
    <nav>
    <a href="/gallery" class="logout-button">Kembali</a>
    </nav>
  </header>
  <form action="/gallery" method="POST">
        @csrf

  <div class="content">
    <h2>Data Album</h2>
    <div class="form-group">
      <label for="album-name">Nama Album:</label>
      <input type="text" id="album-name" name="NamaAlbum" placeholder="Masukkan nama album">
    </div>

    <div class="form-group">
      <label for="album-description">Deskripsi Album:</label>
      <textarea id="album-description" name="Deskripsi" placeholder="Masukkan deskripsi album"></textarea>
    </div>

    <div class="form-group">  
      <button type="submit">Simpan</button>
    </div>
  </div>

  <footer>
    <p>&copy; Website Gallery Foto</p>
  </footer>
</body>
</html>
