<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Register</title>
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      margin: 0;
      padding: 0;
      display: flex;
      flex-direction: column;
      align-items: center;
      height: 120vh;
      background-image: url('asset/images/yaya.jpg');
      background-size: cover; 
    }

    header {
      background-color: #ff9999;
      color: #fff;
      padding: 10px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      width: 100%;
      position: fixed;
      top: 0;
      z-index: 1000; 
      box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);
    }

    h1 {
      margin: 0;
      font-size: 24px; 
    }

    nav {
      display: flex;
      gap: 20px; 
      margin-left: 20px; 
    }

    nav a {
      text-decoration: none;
      color: #fff;
      font-size: 18px;
      margin-right: 10px; 
    }

        nav {
      display: flex;
      gap: 20px; 
      margin-left: 20px; 
    }

    .spacer {
      height: 60px; 
    }

    .register-container {
      background-color: rgba(255, 255, 255, 0.8);
      padding: 20px; 
      border-radius: 8px;
      box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
      max-width: 400px; 
      width: 100%;
      text-align: center;
      margin-top: 80px; 
    }

    .register-container h2 {
      color: #333;
    }

    .form-group {
      margin-bottom: 15px; 
    }

    .form-group label {
      display: block;
      margin-bottom: 5px;  
      color: #555;
    }

    .form-group input {
      width: 100%;
      padding: 8px; 
      border: 1px solid #ddd;
      border-radius: 4px;
      box-sizing: border-box;
    }

    .form-group button {
      background-color: #2ecc71;
      color: #fff;
      padding: 10px 15px; 
      border: none;
      border-radius: 4px;
      cursor: pointer;
      font-size: 14px; 
      transition: background-color 0.3s ease;
    }

    .form-group button:hover {
      background-color: #27ae60;
    }

    .logout-button {
      background: #ffb3b3;
      padding: 8px 16px;
      border-radius: 20px;
    }

    .logout-button:hover {
      background: #00ffff;
    }

    .login-button {
      background: #ffb3b3;
      padding: 8px 16px;
      border-radius: 20px;
    }

    .login-button:hover {
      background: #00ffff;
    }
  </style>
</head>
<body>

  <header>
    <h1>Web Galeri Foto</h1>
    <nav>
    <a href="login" class="login-button">Login</a>
      <a href="/beranda" class="logout-button">Logout</a>
    </nav>
  </header>

  <div class="spacer"></div>

  <div class="register-container">
    <svg xmlns="http://www.w3.org/2000/svg" width="60" height="60" fill="currentColor" class="bi bi-person-circle" viewBox="0 0 16 16">
      <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0"/>
      <path fill-rule="evenodd" d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8m8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1"/>
    </svg>
    <h2>Register</h2>
    <form action="/register" method="post">
    @csrf
    <div class="form-group">
      <label for="name">Username:</label>
      <input type="text" id="username" name="Username" required>
    </div>

    <div class="form-group">
      <label for="password">Password:</label>
      <input type="password" id="password" name="Password" required>
    </div>

    <div class="form-group">
      <label for="email">Email:</label>
      <input type="email" id="email" name="Email" required>
    </div>

    <div class="form-group">
      <label for="name">Nama Lengkap:</label>
      <input type="text" id="name" name="NamaLengkap" required>
    </div>

    <div class="form-group">
      <label for="name">Alamat:</label>
      <input type="text" id="alamat" name="Alamat" required>
    </div>

    <div class="form-group">
      <a href="/login"><button type="Submit">Register</button></a>
    </div>
  </div>
  </form>
</body>
</html>