<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Home</title>
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      margin: 0;
      padding: 0;
      background-size: cover;
      background-color: #ffe6e6;
    }

    header {
      background-color:#ff9999;
      color: #fff;
      padding: 10px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    nav {
      text-align: right;
      padding: 10px;
    }

    nav a {
      color: #333;
      text-decoration: none;
      margin: 0 15px;
      font-size: 18px;
    }

    .content {
      display: flex;
      justify-content: center;
      flex-wrap: wrap;
      padding: 20px;
      text-align: center;
      margin-bottom: 40px;
    }

    footer {
      background-color: #ff9999;
      color: #fff;
      text-align: center;
      padding: 5px;
      position: fixed;
      bottom: 0;
      width: 100%;
    }

    .comment-container {
      width: 100%; /* Menggunakan lebar penuh */
      max-width: 800px; /* Atur lebar maksimum sesuai kebutuhan */
      margin: 20px auto;
      background-color: #f9f9f9;
      border: 1px solid #ccc;
      border-radius: 5px;
      padding: 20px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      display: flex; 
      align-items: flex-start;
    }

    textarea {
      width: calc(100% - 40px);
      padding: 10px;
      margin: 10px 0;
      border: 1px solid #ccc;
      border-radius: 5px;
      resize: vertical;
      text-align: left; /* Mengatur teks menjadi rata kiri */
    }
    
    .logout-button {
      background: #ffb3b3;
      padding: 8px 16px;
      border-radius: 20px;
    }

    .logout-button:hover {
      background: #00ffff;
    }
  </style>
</head>
<body>

  <header>
    <nav>
      <a href="/home" class="logout-button">Kembali</a>
    </nav>
  </header>
  
  <div class="content">
    @foreach($komentar as $item)
    @if($item->FotoID == $FotoID)
        @php
            $nama = $user->where('UserID', $item->UserID)->first();
        @endphp
      <div class="comment-container">
      @if($nama)
        <div style="margin-right: 10px;">{{ $nama->Username }}</div>
        <textarea rows="5">{{ $item->IsiKomentar }}</textarea>
      </div>
      <br>
      <br>
      @endif
      @endif
    @endforeach
  </div>

  <footer>
    <p>&copy;  Website Gallery Foto</p>
  </footer>

</body>
</html>
