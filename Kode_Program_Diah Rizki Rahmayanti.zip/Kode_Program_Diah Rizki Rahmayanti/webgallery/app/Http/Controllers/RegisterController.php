<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Userr;

class RegisterController extends Controller
{
    public function tampildaftar() {
        return view('register');
    }

    public function aksidaftar(Request $request) {
        $request->validate([
            'Username' => 'required',
            'Password' => 'required',
            'Email' => 'required',
            'NamaLengkap' => 'required',
            'Alamat' => 'required',
        ]);

        $data = new Userr();
        $data->username = $request->input('Username');
        $data->password = $request->input('Password');
        $data->email = $request->input('Email');
        $data->namalengkap = $request->input('NamaLengkap');
        $data->alamat = $request->input('Alamat');
        $data->save();
        
        return redirect('/login')->with('success', 'Register berhasil! Silakan login.');
    }
}
