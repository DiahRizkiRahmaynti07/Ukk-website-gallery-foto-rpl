<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facedes\Auth;
use App\Models\Komentar;
use App\Models\Userr;
use App\Models\Foto;
use App\Models\Like;

class LikeController extends Controller
{
    public function lihatfoto($FotoID){
        if(session('DataLogin')){
            $foto = Foto::find($FotoID);
            $like = Likee::all();
            $komentar = Komentar::where('FotoID', $FotoID)->get();
            $user = Userr::find($foto->UserID);
            $user2 = Userr::all();
    
            return view('home', compact('foto','like','komentar','user','user2'));
            
        }
    }
    
    public function like($FotoID)
    {
        $cek = Like::where('UserID',session('DataLogin')->UserID)
                    ->where('FotoID', $FotoID)
                    ->first();
    
            if(!$cek) {
            $data = new Like();
            $data->FotoID = $FotoID;
            $data->UserID = session('DataLogin')->UserID;
            $data->TanggalLike = date('Y-m-d'); 
            $data->save();
    
            return redirect()->back();
            }else{
                $cek->delete();
                return redirect()->back();
            }
    }
    }

