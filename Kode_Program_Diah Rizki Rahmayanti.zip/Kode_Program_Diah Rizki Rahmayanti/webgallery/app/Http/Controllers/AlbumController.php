<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Userr;
use App\Models\Foto;
use App\Models\Album;

class AlbumController extends Controller
{
    public function album()
    {
        if(session ('DataLogin') != null){
            $album = Album::all();
        return view('gallery', ['album' => $album]);
        }else{
            return redirect('/login')->with('success', 'Album berhasil ditambahkan!');
        }
    }

    public function tambahAlbum(Request $request)
    {

        $album = new Album();
        $album->NamaAlbum = $request->input('NamaAlbum');
        $album->Deskripsi = $request->input('Deskripsi');
        $album->TanggalDibuat= date('Y-m-d');
        $album->UserID = session('DataLogin')->UserID;
        $album->save();
        //dd($album);

        return redirect('/gallery')->with('success', 'Album berhasil ditambahkan!');
    }
    
}
