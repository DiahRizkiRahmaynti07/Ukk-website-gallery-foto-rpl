<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Userr;

class LoginController extends Controller
{
    public function tampil()
    {
        if(session('Data Login') == null) {
        return view('login');
    }else{
        return redirect('/home');
     }
    }


    public function login(Request $request)
{
    $request->validate([
        'username' => 'required',
        'password' => 'required',
    ]);

    $data = Userr::where('username', $request->input('username'))
                 ->where('password', $request->input('password'))
                 ->first();

    if ($data === null) {
        return redirect('/login')->with('pesan', 'Username / Password Salah !');
    } else {
        session()->put('DataLogin', $data);
        return redirect('/home')->with('success', 'Selamat Anda Berhasil Login.');
    }
}


public function logout()
{
    session()->flush();
    return redirect('/beranda');
}

}