<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facedes\Auth;
use App\Models\Userr;
use App\Models\Album;
use App\Models\Foto;

class FotoController extends Controller
{

    public function hapusFoto($FotoID)
{
    $foto = Foto::find($FotoID);
    if ($foto && $foto->UserID == session('DataLogin')->UserID) {
        $foto->delete();
        return redirect('/gallery')->with('success', 'Foto berhasil dihapus!');
    }
}
    
    public function foto($AlbumID)
    {
      
        if(session ('DataLogin') != null){
            $album = Album::all();
            $foto = Foto::all();
        return view('tambahfoto', compact('album', 'foto','AlbumID'));
        }else{
            return redirect('/login')->with('success', 'Album berhasil ditambahkan!');
        }
    }

    public function foto2($AlbumID)
    {
      
        if(session ('DataLogin') != null){
            $foto = Foto::all();
        return view('foto', compact('foto', 'AlbumID'));
        }else{
            return redirect('/login')->with('success', 'Album berhasil ditambahkan!');
        }
    }

    public function home1()
    {
        if(session ('DataLogin') == null){
            $foto = Foto::all();
        return view('beranda', ['foto' => $foto]);
        }else{
            return redirect('/login')->with('success', 'Album berhasil ditambahkan!');
        }
    }

    public function home()
    {
        if(session ('DataLogin') != null){
            $foto = Foto::all();
        return view('home', ['foto' => $foto]);
        }else{
            return redirect('/login')->with('success', 'Album berhasil ditambahkan!');
        }
    }

    public function tambahFoto(Request $request,$AlbumID)
    {
        $filefoto =$request->file('foto');
        $filefoto->move('folder',$filefoto->getClientOriginalName());

        $data = new Foto();
        $data -> JudulFoto = $request->input('JudulFoto');
        $data -> DeskripsiFoto = $request->input('DeskripsiFoto');
        $data -> TanggalUnggah = date('Y-m-d');
        $data -> LokasiFile = '/folder/'.$filefoto->getClientOriginalName();
        $data -> UserID = session ('DataLogin')->UserID;
        $data -> AlbumID = $AlbumID;
        $data -> save();
        // dd($album);

        Session()->flash('success', 'Album Berhasil ditambahkan !');
        return redirect ('/gallery');
    }

}

