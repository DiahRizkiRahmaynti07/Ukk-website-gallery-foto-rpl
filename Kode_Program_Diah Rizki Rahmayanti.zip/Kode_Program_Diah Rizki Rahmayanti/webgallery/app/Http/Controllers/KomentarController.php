<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facedes\Auth;
use App\Models\Komentar;
use App\Models\Userr;
use App\Models\Foto;

class KomentarController extends Controller
{
    public function tampilkomentar($FotoID)
    {
        if (session('DataLogin') != null) {
            $komentar = komentar::all();
            return view('komentar', compact('komentar', 'FotoID'));
        }else{
            return redirect('/login')->with('pesanbaru', 'silahkan login terlebih dahulu !');
        }
    }

    public function lihatkomentar($FotoID)
    {
        if (session('DataLogin') != null) {
            $komentar = komentar::all();
            $user = Userr::all();
            return view('lihatkomentar', compact('komentar','user', 'FotoID'));
        }else{
            return redirect('/login')->with('pesanbaru', 'silahkan login terlebih dahulu !');
        }
    }

        public function tambahkomentar(Request $request,$FotoID)
        {
        $data = new komentar();
        $data->IsiKomentar = $request->input('IsiKomentar');
        $data->TanggalKomentar = date('Y-m-d');
        $data->UserID = session ('DataLogin')->UserID;
        $data->FotoID = $FotoID;
        $data->save();

        // Redirect atau melakukan tindakan lainnya sesuai kebutuhan
        return redirect('/lihatkomentar/'.$FotoID)->with('pesanbaru', 'komentar berhasil dikirim');
    }

}


