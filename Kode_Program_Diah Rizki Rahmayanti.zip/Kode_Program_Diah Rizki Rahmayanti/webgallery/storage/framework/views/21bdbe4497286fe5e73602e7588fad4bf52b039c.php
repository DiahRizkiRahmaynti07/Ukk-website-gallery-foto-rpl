<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Komentar</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: url('Asset/images/gg.jpg');
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background-color: #ffe6e6; 
        }

        header {
      background-color: #ff9999;
      color: #fff;
      padding: 10px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      width: 100%;
      position: fixed;
      top: 0;
      z-index: 1000; 
      box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);
    }

    nav {
      display: flex;
      gap: 30px;
      margin-right: 20px;
    }

    nav a {
      text-decoration: none;
      color: #fff;
      font-size: 20px;
    }

        .comment-container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .comment-form {
            max-width: 500px;
            background-color: #f9f9f9;
            border: 1px solid #ccc;
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .comment-form textarea {
            width: 100%;
            padding: 15px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 8px;
            resize: vertical;
            font-size: 16px;
        }

        .comment-form button {
            width: 100%;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 8px;
            padding: 15px 0;
            cursor: pointer;
            font-size: 16px;
        }

        .comment-form button:hover {
            background-color: #0056b3;
        }

        .logout-button {
            background: #ffb3b3;
            padding: 8px 16px;
            border-radius: 20px;
            text-decoration: none;
            color: #fff;
        }

        .logout-button:hover {
            background: #00ffff;
        } 

        footer {
      background-color: #ff9999;
      color: #fff;
      text-align: center;
      padding: 5px;
      position: fixed;
      bottom: 0;
      width: 100%;
    }
    </style>
</head>
<body>
<header>
    <nav>
        <a href="/home" class="logout-button">Kembali</a>
    </nav>
</header>
<br>
<br>
<div class="comment-container">
    <form action="/lihatkomentar/<?php echo e($FotoID); ?>" method="post" class="comment-form">
        <?php echo csrf_field(); ?>
        Komentar :
        <br>
        <br>
        <textarea name="IsiKomentar" placeholder="Tambahkan komentar" rows="5"></textarea>
        <button type="submit" class="submit-button">Kirim</button>
    </form>
</div>

<footer>
    <p>&copy; Website Gallery Foto</p>
  </footer>
</body>
</html>
<?php /**PATH C:\laragon\www\webgallery\resources\views/komentar.blade.php ENDPATH**/ ?>