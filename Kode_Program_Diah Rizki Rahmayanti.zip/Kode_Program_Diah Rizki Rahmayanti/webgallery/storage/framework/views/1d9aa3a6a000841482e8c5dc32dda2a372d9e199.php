<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Home</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" integrity="sha512-...">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" integrity="sha512-..." crossorigin="anonymous" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" integrity="sha512-..." crossorigin="anonymous" />
  <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">


  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      margin: 0;
      padding: 0;
      background-image: url('asset/images/yaya.jpg');
      background-size: cover;
    }

    header {
      background-color: #ff9999;
      color: #fff;
      padding: 10px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    h1 {
      margin: 0;
    }

    h2 {
      margin-bottom: 20px;
      margin-left: 20px;
    }

    nav {
      text-align: right;
      padding: 10px;
    }

    nav a {
      color: #333;
      text-decoration: none;
      margin: 0 15px;
      font-size: 18px;
    }

    .welcome-text h2 {
      font-size: 35px;
    }

    .welcome-text {
      text-align: center;
      padding: 20px;
      background-color: rgba(255, 255, 255, 0.8);
      border-radius: 8px;
      box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
      margin: 20px;
      background-color: #ff9999;
    }

    .content {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      gap: 20px;
      padding: 20px;
    }

    .feature-box {
      background-color: #fff;
      border-radius: 8px;
      box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
      padding: 20px;
      width: 300px;
      text-align: center;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      height: 100%;
      margin-bottom: 70px; /* Menambahkan margin-bottom */
    }

    .feature-box img {
      width: 100%;
      border-radius: 8px;
      margin-bottom: 10px;
    }

    .interaction-buttons {
      display: flex;
      justify-content: space-between;
      align-items: center; 
      margin-top: auto;
      padding-top: 10px; 
    }

    .interaction-buttons .btn {
      flex: 1;
      margin: 0 5px;
    }

    .icon-button {
      background: #ffb3b3;
      padding: 8px 16px;
      border-radius: 20px;
    }

    .icon-button:hover {
      background: #00ffff;
    }

    .icon-button svg {
      width: 23px;
      height: 23px;
      fill: currentColor;
    }

    .icon-button:hover svg {
      fill: #ff0000;
    }

    .gallery-button,
    .logout-button {
      flex: 1;
    }

    .gallery-button {
      background: #ffb3b3;
      padding: 8px 16px;
      border-radius: 20px;
    }

    .gallery-button:hover {
      background: #00ffff;
    }

    .logout-button {
      background: #ffb3b3;
      padding: 8px 16px;
      border-radius: 20px;
    }

    .logout-button:hover {
      background: #00ffff;
    }
    

    /* New CSS for interaction buttons */
    .interaction-buttons {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-top: auto;
      padding-top: 10px; 
    }

    .interaction-buttons .icon-button {
      flex: 1;
      margin: 0 5px;
    }

    footer {
      background-color: #ff9999;
      color: #fff;
      text-align: center;
      padding: 5px;
      position: fixed;
      bottom: 0;
      width: 100%;
    }

    .feature-box h4,
    .feature-box p {
      font-weight: normal;
    }
  </style>
</head>
<body>
  <header>
    <h1>Web Galeri Foto</h1>
    <nav>
      <?php if(session('DataLogin') ==!null): ?>
      <?php endif; ?>
      <a href="/register" class="gallery-button">Register</a>
      <a href="/login" class="logout-button">Login</a>
    </nav>
  </header>

  <div class="welcome-text">
    <h2>Selamat Datang di Website Galeri Foto</h2>
  </div>

  <h2>Foto Terbaru</h2>

  <div class="content">
    <?php $__currentLoopData = $foto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="feature-box">
      <img src="<?php echo e($item->LokasiFile); ?>" class="brand_logo" alt="Logo">
      <h4 class="card-title" style="margin-bottom: 0;"><span>Judul Foto:<?php echo e($item->JudulFoto); ?></span></h4>
      <p class="card-text"><span>Deskripsi:<?php echo e($item->DeskripsiFoto); ?></span></p>
      <p class="card-text"><span>Tanggal Unggah:<?php echo e($item->TanggalUnggah); ?></span></p>
      <form>
        
        <button type="submit" class="btn btn-sm btn-outline-secondary" style=" background-color:#e6b3ff;color:black;"><i class="far fa-thumbs-up"></i> Like <?php echo e(\App\Models\Like::where('FotoID', $item->FotoID)->count()); ?></button>
        
        <a href ="/komentar/<?php echo e($item->FotoID); ?>" class="btn btn-sm btn-outline-secondary" style="background-color:#e6b3ff;color:black;"><i class="far fa-comment"></i> Komentar </a>
        <a href ="/lihatkomentar/<?php echo e($item->FotoID); ?>" class="btn btn-sm btn-outline-secondary" style=" background-color:#e6b3ff;color:black;"> <?php echo e(\App\Models\Komentar::where('FotoID', $item->FotoID)->count()); ?></a>
    
         
        </a>
      </form>
      
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>

  <footer>
    <p>&copy;  Website Gallery Foto</p>
  </footer>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/js/all.min.js"></script>
</body>
</html>
<?php /**PATH C:\laragon\www\webgallery\resources\views/beranda.blade.php ENDPATH**/ ?>