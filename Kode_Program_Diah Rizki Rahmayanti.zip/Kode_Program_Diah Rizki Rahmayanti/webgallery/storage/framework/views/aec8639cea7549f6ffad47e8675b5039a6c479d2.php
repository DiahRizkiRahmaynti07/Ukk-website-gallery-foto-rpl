<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Home</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      margin: 0;
      padding: 0;
      background-image: url('Asset/images/gg.jpg');
      background-size: cover;
      background-color: #ffe6e6; 
    }

    header {
      background-color:#ff9999;
      color: #fff;
      padding: 10px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    nav {
      text-align: right;
      padding: 10px;
    }

    nav a {
      color: #333;
      text-decoration: none;
      margin: 0 15px;
      font-size: 18px;
    }


    .content {
      display: flex;
      flex-wrap: wrap;
      justify-content: center; /* Tambahkan ini */
      align-items: flex-start; /* Tambahkan ini */
      gap: 20px; /* Tambahkan ini */
      padding: 20px;
      text-align: center;
      margin-bottom: 40px;
    }

    footer {
      background-color: #ff9999;
      color: #fff;
      text-align: center;
      padding: 5px;
      position: fixed;
      bottom: 0;
      width: 100%;
    }

    .gallery-button {
      background: #ffb3b3;
      padding: 8px 16px;
      border-radius: 20px;
    }

    .gallery-button:hover {
      background: #00ffff;
    }

    .logout-button {
      background: #ffb3b3;
      padding: 8px 16px;
      border-radius: 20px;
    }

    .logout-button:hover {
      background: #00ffff;
    }

    .tambahfoto-button {
      background: #ffb3b3;
      padding: 8px 16px;
      border-radius: 20px;
    }

    .tambahfoto-button:hover {
      background: #00ffff;
    }
    

    .feature-box {
      background-color: #fff;
      border-radius: 8px;
      box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
      padding: 20px;
      width: 300px;
      text-align: center;
    }

    .feature-box img {
      width: 100%;
      border-radius: 8px;
      margin-bottom: 10px;
    }

    .feature-box h4,
    .feature-box p {
      font-weight: normal;
    }
  </style>
</head>
<body>

  <header>
    <nav> 
      <?php if(session('DataLogin') ==!null): ?>
      <a href="/logout" class="btn btn-danger btn-my-2">
        <?php endif; ?>
      <a href="/gallery" class="gallery-button">kembali</a>
    </nav>
  </header>

  <br>
  <br>
  <center>
  <div class="welcome-text">
    <a href="/foto/<?php echo e($AlbumID); ?>" class="tambahfoto-button" style="text-decoration: none;">Tambah Foto</a>
  </div>
</center>

  <div class="content">
   <?php $__currentLoopData = $foto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php if(session()->get('DataLogin')->UserID == $item->UserID && $item->AlbumID == $AlbumID): ?>
    <div class="feature-box">
      <img src="<?php echo e($item->LokasiFile); ?>" class="brand_logo" alt="Logo">
      <h4 class="card-title" style="margin-bottom: 0;">Judul Foto: <span><?php echo e($item->JudulFoto); ?></span></h4>
      <p class="card-text">Deskripsi: <span><?php echo e($item->DeskripsiFoto); ?></span></p>
      <p class="card-text">Tanggal Unggah: <span><?php echo e($item->TanggalUnggah); ?></span></p>
      <a href="/hapusfoto/<?php echo e($item->FotoID); ?>" class="btn btn-danger" style="background-color:#e6b3ff;color:black;text-decoration:none;padding:10px 20px;"><i class="bi bi-trash"></i> Hapus Foto</a>
    </div>
  <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


  <footer>
    <p>&copy; Website Gallery Foto</p>
  </footer>

</body>
</html>
<?php /**PATH C:\laragon\www\webgallery\resources\views/tambahfoto.blade.php ENDPATH**/ ?>