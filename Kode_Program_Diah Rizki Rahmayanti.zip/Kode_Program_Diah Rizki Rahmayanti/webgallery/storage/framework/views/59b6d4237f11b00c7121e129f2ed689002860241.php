<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Foto</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-image: url('Asset/images/gg.jpg');
            background-size: cover;
            background-color: #ffe6e6;
        }

        h1 {
            text-align: center;
            margin-top: 50px;
            margin-bottom: 30px;
        }

        header {
      background-color: #ff9999;
      color: #fff;
      padding: 10px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      width: 100%;
      position: fixed;
      top: 0;
      z-index: 1000; 
      box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);
    }

    nav {
      display: flex;
      gap: 30px;
      margin-right: 20px;
    }

    nav a {
      text-decoration: none;
      color: #fff;
      font-size: 20px;
    }

        form {
            width: 50%;
            margin: 0 auto;
        }

        label {
            display: block;
            margin-bottom: 10px;
        }

        input[type="text"], textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        button[type="submit"] {
            background-color: #ffb3b3;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button[type="submit"]:hover {
            background-color: #ff6666;
        }
    </style>
</head>
<body>

<header>
    <nav>
      <a href="/home" class="logout-button">Kembali</a>
    </nav>
  </header>
<form action="/updatefoto/<?php echo e($foto->FotoID); ?>" method="post">
    <?php echo csrf_field(); ?>
    <label for="JudulFoto">Judul Foto:</label><br>
    <input type="text" id="JudulFoto" name="JudulFoto" value="<?php echo e($foto->JudulFoto); ?>"><br>
    <label for="DeskripsiFoto">Deskripsi Foto:</label><br>
    <textarea id="DeskripsiFoto" name="DeskripsiFoto"><?php echo e($foto->DeskripsiFoto); ?></textarea><br>
    <button type="submit">Simpan Perubahan</button>
</form>

</body>
</html>
<?php /**PATH C:\laragon\www\webgallery\resources\views/editfoto.blade.php ENDPATH**/ ?>